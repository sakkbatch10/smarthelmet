from django.apps import AppConfig


class HelmetConfig(AppConfig):
    name = 'helmet'
